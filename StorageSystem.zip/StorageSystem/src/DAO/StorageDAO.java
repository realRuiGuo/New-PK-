package DAO;

import java.util.List;

import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import Object.Storage;

/**
 * A data access object (DAO) providing persistence and search support for
 * Storage entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see DAO.Storage
 * @author MyEclipse Persistence Tools
 */
public class StorageDAO extends BaseHibernateDAO {
	private static final Logger log = LoggerFactory.getLogger(StorageDAO.class);
	// property constants
	public static final String NUMBER = "number";
	public static final String MAX = "max";
	public static final String STORAGECOL = "storagecol";
	   public Transaction tx;

	public void save(Storage transientInstance) {
		tx=getSession().beginTransaction();
		log.debug("saving Storage instance");
		try {
			getSession().save(transientInstance);
			log.debug("save successful");
			tx.commit();
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(Storage persistentInstance) {
		tx=getSession().beginTransaction();
		log.debug("deleting Storage instance");
		try {
			getSession().delete(persistentInstance);
			log.debug("delete successful");
			tx.commit();
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Storage findById(java.lang.String id) {
		log.debug("getting Storage instance with id: " + id);
		try {
			Storage instance = (Storage) getSession().get("Object.Storage", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(Storage instance) {
		log.debug("finding Storage instance by example");
		try {
			List results = getSession().createCriteria("Object.Storage")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding Storage instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from Storage as model where model."
					+ propertyName + "= ?";
			Query queryObject = getSession().createQuery(queryString);
			queryObject.setParameter(0, value);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByNumber(Object number) {
		return findByProperty(NUMBER, number);
	}

	public List findByMax(Object max) {
		return findByProperty(MAX, max);
	}

	public List findByStoragecol(Object storagecol) {
		return findByProperty(STORAGECOL, storagecol);
	}

	public List findAll() {
		log.debug("finding all Storage instances");
		try {
			String queryString = "from Storage";
			Query queryObject = getSession().createQuery(queryString);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public Storage merge(Storage detachedInstance) {
		tx=getSession().beginTransaction();
		log.debug("merging Storage instance");
		try {
			Storage result = (Storage) getSession().merge(detachedInstance);
			log.debug("merge successful");
			tx.commit();
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(Storage instance) {
		log.debug("attaching dirty Storage instance");
		try {
			getSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Storage instance) {
		log.debug("attaching clean Storage instance");
		try {
			getSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}
}