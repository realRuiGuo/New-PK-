package Object;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import View.BeanColumn;
/**
 * Plan entity. @author MyEclipse Persistence Tools
 */

public class Plan implements java.io.Serializable,PropertyChangeListener{

	// Fields
	@BeanColumn(name = "������", index = 0)
	private String goodsid;
	@BeanColumn(name = "��Ŀ", index = 1)
	private Integer number;

	// Constructors

	/** default constructor */
	public Plan() {
	}

	/** full constructor */
	public Plan(String goodsid, Integer number) {
		this.goodsid = goodsid;
		this.number = number;
	}

	// Property accessors

	public String getGoodsid() {
		return this.goodsid;
	}

	public void setGoodsid(String goodsid) {
		this.goodsid = goodsid;
	}

	public Integer getNumber() {
		return this.number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}
	
	
	@Override
	public void propertyChange(PropertyChangeEvent evt) {

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((goodsid == null) ? 0 : goodsid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Plan other = (Plan) obj;
		if (goodsid == null) {
			if (other.goodsid != null)
				return false;
		} else if (!goodsid.equals(other.goodsid))
			return false;
		return true;
	}
}