package Object;

/**
 * Storage entity. @author MyEclipse Persistence Tools
 */

public class Storage implements java.io.Serializable {

	// Fields

	private String goodsid;
	private Integer number;
	private Integer max;
	private String storagecol;

	// Constructors

	/** default constructor */
	public Storage() {
	}

	/** full constructor */
	public Storage(String goodsid, Integer number, Integer max,
			String storagecol) {
		this.goodsid = goodsid;
		this.number = number;
		this.max = max;
		this.storagecol = storagecol;
	}

	// Property accessors

	public String getGoodsid() {
		return this.goodsid;
	}

	public void setGoodsid(String goodsid) {
		this.goodsid = goodsid;
	}

	public Integer getNumber() {
		return this.number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public Integer getMax() {
		return this.max;
	}

	public void setMax(Integer max) {
		this.max = max;
	}

	public String getStoragecol() {
		return this.storagecol;
	}

	public void setStoragecol(String storagecol) {
		this.storagecol = storagecol;
	}

}