package System;

import java.util.ArrayList;

import Object.*;

public class PlanningControl {

	private DAO.StorageDAO daoStorage;
	private DAO.PlanDAO daoPlan;

	public PlanningControl() {
		daoStorage = new DAO.StorageDAO();
		daoPlan = new DAO.PlanDAO();
	}
//�����ɹ��ƻ�
	public ArrayList<Plan> createPlan(ArrayList<Plan> formline) {
		ArrayList<Plan> tempForm = new ArrayList<Plan>();
		for (int i = 0; i < formline.size(); i++) {
			String id = formline.get(i).getGoodsid();
			Storage storageForm = daoStorage.findById(id);
			int restContain = storageForm.getMax() - storageForm.getNumber();
			Plan planForm = daoPlan.findById(id);
			int allCount = planForm.getNumber() + formline.get(i).getNumber();
			if (restContain >= allCount) {
				tempForm.add(formline.get(i));
			} else {
				formline.get(i).setNumber(restContain - planForm.getNumber());
				tempForm.add(formline.get(i));
			}
		}

		return tempForm;
	}
//���¼ƻ�
	public void updatePlan(Boolean selection, ArrayList<Plan> formline) {
		if (selection == true) {
			for (int i = 0; i < formline.size(); i++) {
				daoPlan.merge(formline.get(i));
			}
		}
	}

}
