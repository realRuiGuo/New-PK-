package System;

import java.util.ArrayList;
import Object.*;

public class ShippingControl {

	private DAO.GoodsDAO daoGoods;
	private DAO.StorageDAO daoStorage;

	public ShippingControl() {
		daoGoods = new DAO.GoodsDAO();
		daoStorage = new  DAO.StorageDAO();
	}

	// ������ʱ������
	public ArrayList<Plan> createTempTable(ArrayList<Plan> formline) {
		ArrayList<Plan> tempForm = new ArrayList<Plan>();
		for (int i = 0; i < formline.size(); i++) {
			String ID = formline.get(i).getGoodsid();
			if (daoGoods.findById(ID) != null) {
				tempForm.add(formline.get(i));
			}
		}
		return tempForm;
	}

	// ���ɳ�����
	public ArrayList<Plan> createTable(ArrayList<Plan> formline) {
		ArrayList<Plan> tempForm = new ArrayList<Plan>();
		for (int i = 0; i < formline.size(); i++) {
			Storage form = daoStorage.findById(formline.get(i).getGoodsid());
			if (form.getNumber().compareTo(formline.get(i).getNumber()) >= 0) {
				tempForm.add(formline.get(i));
				int rest = form.getNumber() - formline.get(i).getNumber();
				form.setNumber(rest);
				daoStorage.merge(form);
			} else {
				Plan tableLine = new Plan(formline.get(i).getGoodsid(),
						form.getNumber());
				tempForm.add(tableLine);
				form.setNumber(0);
				daoStorage.merge(form);
			}

		}

		return tempForm;
	}

	// ������ʱ�ƻ�
	public ArrayList<Plan> createTempPlan(ArrayList<Plan> formline) {
		ArrayList<Plan> tempForm = new ArrayList<Plan>();
		for (int i = 0; i < formline.size(); i++) {
			Storage form = daoStorage.findById(formline.get(i).getGoodsid());
			if (form.getNumber().compareTo(formline.get(i).getNumber()) < 0) {
				int count = formline.get(i).getNumber() - form.getNumber();
				Plan tableLine = new Plan(formline.get(i).getGoodsid(), count);
				tempForm.add(tableLine);
			}
		}
		return tempForm;
	}

}
