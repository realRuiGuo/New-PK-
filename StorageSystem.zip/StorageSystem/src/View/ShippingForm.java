package View;

import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.SwingUtilities;

import Object.Plan;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class ShippingForm extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JScrollPane jScrollPane1;
	private JTable jTable1;

	/**
	 * Auto-generated main method to display this JFrame
	 */

	public ShippingForm(ArrayList<Plan> form) {
		super();
		initGUI(form);	
	}

	private void initGUI(ArrayList<Plan> form) { 
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1);
				jPanel1.setBounds(-5, 0, 265, 223);
				jPanel1.setBackground(java.awt.Color.WHITE);
				jPanel1.setLayout(null);
				{
					jScrollPane1 = new JScrollPane();
					jPanel1.add(jScrollPane1);
					jScrollPane1.setBounds(7, 0, 258, 217);
					{
						// TableModel jTable1Model = new DefaultTableModel(
						// new String[][] { { "One", "Two" },
						// { "Three", "Four" } }, new String[] {
						// "Column 1", "Column 2" });
						jTable1 = new JTable();
						jScrollPane1.setViewportView(jTable1);
						
						final ArrayList<Plan> forms = form;

						final TableModel tableModel = new MyTableModel<Plan>(
								forms);

						jTable1.setModel(tableModel);
						for (int i = 0; i < forms.size(); i++) {
							((MyTableModel<Plan>) tableModel).update(i,
									forms.get(i));

						}
						jTable1.setPreferredSize(new java.awt.Dimension(255,
								193));
					}
				}
			}
			pack();
			this.setSize(276, 262);
		} catch (Exception e) {
			// add your error handling code here
			e.printStackTrace();
		}
	}

}
