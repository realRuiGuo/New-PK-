package View;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.table.*;

import Object.*;
import System.*;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class Storage extends javax.swing.JFrame {
	private JPanel jPaneltable1;
	private JButton jButton1;
	private JTextArea jTextArea3;
	private JTextArea jTextArea2;
	private JTextArea jTextArea1;
	private JTextField jTextField3;
	private JTextField jTextField2;
	private JButton jButton4;
	private JButton jButton3;
	private JTable jTable1;
	private JScrollPane jScrollPane1;
	private JButton jButton2;
	private JPanel function;
	public static ArrayList<Plan> storageForm = null;

	/**
	 * Auto-generated main method to display this JFrame
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Storage inst = new Storage();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}

	public Storage() {
		super();
		initGUI();
	}

	private void initGUI() {
		storageForm = new ArrayList<Plan>();
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			{
				jPaneltable1 = new JPanel();
				getContentPane().add(jPaneltable1, "Center");
				jPaneltable1.setBounds(139, 0, 424, 412);
				jPaneltable1.setLayout(null);
				jPaneltable1.setBackground(java.awt.Color.WHITE);
				{
					jScrollPane1 = new JScrollPane();
					jPaneltable1.add(jScrollPane1);
					jScrollPane1.setBounds(0, 50, 418, 220);
					jScrollPane1.setBackground(Color.GRAY);
					{
						jTable1 = new JTable();
						jScrollPane1.setViewportView(jTable1);
						jTable1.setBounds(1, 102, 411, 163);
						jTable1.setPreferredSize(new java.awt.Dimension(415,
								217));
					}
				}

				{
					jButton3 = new JButton();
					jPaneltable1.add(jButton3);
					jButton3.setText("\u589e\u52a0\u6761\u76ee");
					jButton3.setBackground(Color.white);
					jButton3.setForeground(Color.black);
					jButton3.setBounds(63, 355, 89, 46);

				}
				{
					jButton4 = new JButton();
					jPaneltable1.add(jButton4);
					jButton4.setText("\u5220\u9664\u6761\u76ee");
					jButton4.setBackground(Color.white);
					jButton4.setForeground(Color.black);
					jButton4.setBounds(304, 355, 89, 46);

				}

				{
					jTextField2 = new JTextField();
					jPaneltable1.add(jTextField2);
					jTextField2.setBounds(109, 305, 67, 24);
				}
				{
					jTextField3 = new JTextField();
					jPaneltable1.add(jTextField3);
					jTextField3.setBounds(290, 305, 67, 24);
				}
				{
					jTextArea1 = new JTextArea();
					jPaneltable1.add(jTextArea1);
					jTextArea1.setText("\u8d27\u7269\u7f16\u53f7\uff1a");
					jTextArea1.setBounds(45, 306, 60, 21);
				}
				{
					jTextArea2 = new JTextArea();
					jPaneltable1.add(jTextArea2);
					jTextArea2.setText("\u6570\u76ee\uff1a");
					jTextArea2.setBounds(252, 305, 38, 22);
				}
				{
					jTextArea3 = new JTextArea();
					jPaneltable1.add(jTextArea3);
					jTextArea3.setText("\u8d27\u7269\u6e05\u5355");
					jTextArea3.setBounds(193, 12, 49, 26);
				}

				final MyTableModel<Plan> tableModel = new MyTableModel<Plan>(
						storageForm);
				jTable1.setModel(tableModel);

				jButton3.addActionListener(new ActionListener() {
					// ����
					public void actionPerformed(ActionEvent e) {

						if (jTextField2.getText().equals("")
								|| jTextField3.getText().equals("")) {
							JOptionPane.showMessageDialog(null, "�������룡");
						} else {
							Plan formLine = new Plan(jTextField2.getText(),
									Integer.valueOf(jTextField3.getText()));
							storageForm.add(formLine);
							for (int i = 0; i < storageForm.size(); i++) {
								((MyTableModel<Plan>) tableModel).update(i,
										storageForm.get(i));
								MyTableModel tempTableModel = ((MyTableModel) jTable1
										.getModel());
								tempTableModel.fireTableDataChanged();// ����ȫ������
							}
							jTextField2.setText("");
							jTextField3.setText("");
						}
					}

				});
				// ɾ��
				jButton4.addActionListener(new ActionListener() {//
					public void actionPerformed(ActionEvent e) {
						int selectedRow = jTable1.getSelectedRow();
						if (selectedRow != -1) {
							if (jTextField2.getText().equals("")
									|| jTextField3.getText().equals("")) {
								JOptionPane.showMessageDialog(null, "�������룡");
							} else {
							Plan formLine = new Plan(jTextField2.getText(),
									Integer.valueOf(jTextField3.getText()));
							// ���ѡ���е�����
							MyTableModel tableModel = ((MyTableModel) jTable1
									.getModel());
							tableModel.deleteRow(selectedRow);
							storageForm.remove(formLine);
							tableModel.fireTableDataChanged();
							}
						}
					}
				});

				jTable1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // ��ѡ
				jTable1.addMouseListener(new MouseAdapter() { // ����¼�
					public void mouseClicked(MouseEvent e) {
						int selectedRow = jTable1.getSelectedRow(); // ���ѡ��������
						if(selectedRow == -1)
						{
							JOptionPane.showMessageDialog(null, "��ѡ����Ŀ��");
						}
						else{
						Object oa = tableModel.getValueAt(selectedRow, 0);
						Object ob = tableModel.getValueAt(selectedRow, 1);
						jTextField2.setText(oa.toString()); // ���ı���ֵ
						jTextField3.setText(ob.toString());
						}
					}
				});

			}

			{
				function = new JPanel();
				getContentPane().add(function);
				function.setLayout(null);
				function.setBounds(-6, 0, 145, 412);
				function.setBackground(java.awt.Color.GRAY);
				{
					jButton1 = new JButton();
					function.add(jButton1);
					jButton1.setText("\u751f\u6210\u51fa\u8d27\u5355");
					jButton1.setBackground(Color.black);
					jButton1.setForeground(Color.white);
					jButton1.setBounds(12, 89, 122, 72);
					jButton1.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							ShippingControl SC = new ShippingControl();
							ArrayList<Plan> tempTable = SC
									.createTempTable(storageForm);
							ArrayList<Plan> shippingForm = SC
									.createTable(tempTable);
							if (shippingForm != null) {
								ShippingForm form = new ShippingForm(
										shippingForm);
								form.setTitle("������");
								form.setVisible(true);
								form.setLocationRelativeTo(null);
							} else {
								JOptionPane
										.showMessageDialog(null, "������������嵥��");
							}
						}
					});

				}
				{
					jButton2 = new JButton();
					function.add(jButton2);
					jButton2.setText("\u751f\u6210\u91c7\u8d2d\u8ba1\u5212");
					jButton2.setBackground(Color.black);
					jButton2.setForeground(Color.white);
					jButton2.setBounds(12, 247, 122, 69);
					jButton2.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							ShippingControl SC = new ShippingControl();
							ArrayList<Plan> tempTable = SC
									.createTempTable(storageForm);
							ArrayList<Plan> shippingForm = SC
									.createTable(tempTable);
							ArrayList<Plan> tempPlan = SC
									.createTempPlan(tempTable);
							PlanningControl PC = new PlanningControl();
							ArrayList<Plan> planningForm = PC
									.createPlan(tempPlan);
							PC.updatePlan(true, planningForm);
							if (planningForm != null) {
								ShippingForm form = new ShippingForm(
										planningForm);

								form.setTitle("�ɹ��ƻ�");
								form.setVisible(true);
								form.setLocationRelativeTo(null);
							} else {
								JOptionPane
										.showMessageDialog(null, "������������嵥��");
							}
						}
					});
				}
			}
			pack();
			this.setSize(573, 451);
		} catch (Exception e) {
			// add your error handling code here
			e.printStackTrace();
		}
	}

}
